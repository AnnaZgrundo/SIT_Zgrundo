/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

/**
 *
 * @author Sparksonet
 */
public enum ECommand {

    READ_NEWS, READ_AJAX, ADD_NEWS, ADD_AJAX, DELETE_NEWS,  DELETE_AJAX, ADD_AUTHOR, DELETE_AUTHOR,
    READ_AUTHOR, READ_STATS, READ_TOP_NEWS, READ_PERSON;

}
