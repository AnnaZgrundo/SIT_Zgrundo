/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Articles;
import entity.Users;
import java.io.IOException;
import java.util.Enumeration;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import session.ArticlesFacade;
import session.UsersFacade;

/**
 *
 * @author Tatiana
 */
@WebServlet(name = "web_controller", loadOnStartup = 1, urlPatterns = {"/article", "/registration", "/index", "/remote", "/update"})
public class WebController extends HttpServlet {

    @EJB
    ArticlesFacade articlesFacade;
    @EJB
    UsersFacade usersFacade;

    @Override
    public void init() throws ServletException {
        getServletContext().setAttribute("articles", articlesFacade.findAll());

    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String userPath = request.getServletPath();
        System.out.println(userPath);
        String page = request.getServletPath();
        if ("/article".equals(userPath)) {
            String id = null;
            Enumeration<String> params = request.getParameterNames();
            while (params.hasMoreElements()) {
                String param = params.nextElement();
                id = "id".equals(param) ? request.getParameter(param) : id;
                page = "/WEB-INF/views" + userPath + ".jsp";
            }
            try {
                Articles article = articlesFacade.find(Integer.parseInt(id));
                request.setAttribute("article", article);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if ("/registration".equals(userPath)) {
            String login = null;
            String password = null;
            String title = null;
            String text = null;
            Enumeration<String> params = request.getParameterNames();

            while (params.hasMoreElements()) {
                String param = params.nextElement();
                System.out.println("param " + param);
                login = "login".equals(param) ? request.getParameter(param) : login;
                password = "password".equals(param) ? request.getParameter(param) : password;
                title = "title".equals(param) ? request.getParameter(param) : title;
                text = "text".equals(param) ? request.getParameter(param) : text;

            }
            System.out.println("login: " + login + " password: " + password);
            System.out.println("text: " + text + " title: " + title);
            if (login != null && password != null) {
                try {
                    Users user = new Users(login, password);
                    System.out.println(user.toString());
                    usersFacade.create(user);
                    request.setAttribute("message", "User Create");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (text != null && title != null) {
                List< Articles> article = articlesFacade.findAll();
                int id = 0;
                for (Articles obj : article) {
                    id = obj.getId();
                }
                id++;
                Articles article2 = new Articles(id, title, text, java.util.Calendar.getInstance().getTime());
                articlesFacade.create(article2);
                request.setAttribute("message", "Article Create");
            }
            page = "/WEB-INF/views" + userPath + ".jsp";
        } else if ("/remote".equals(userPath)) {
            String login = null;
            String id = null;

            Enumeration<String> params = request.getParameterNames();

            while (params.hasMoreElements()) {
                String param = params.nextElement();
                System.out.println("param " + param);
                login = "login".equals(param) ? request.getParameter(param) : login;
                id = "id".equals(param) ? request.getParameter(param) : id;

            }

            if (login != null) {
                try {
                    Users user = usersFacade.find(login);
                    usersFacade.remove(user);
                    request.setAttribute("message", "User Remote");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (id != null) {
                Articles article = articlesFacade.find(Integer.parseInt(id));
                articlesFacade.remove(article);
                request.setAttribute("message", "Article Remote");
            }
            page = "/WEB-INF/views" + userPath + ".jsp";
        } else if ("/update".equals(userPath)) {
            String login = null;
            String password = null;
            String title = null;
            String text = null;
            String id = null;
            Enumeration<String> params = request.getParameterNames();

            while (params.hasMoreElements()) {
                String param = params.nextElement();
                System.out.println("param " + param);
                login = "login".equals(param) ? request.getParameter(param) : login;
                password = "password".equals(param) ? request.getParameter(param) : password;
                title = "title".equals(param) ? request.getParameter(param) : title;
                text = "text".equals(param) ? request.getParameter(param) : text;
                id = "id".equals(param) ? request.getParameter(param) : id;

            }
            System.out.println("login: " + login + " password: " + password);
            System.out.println("text: " + text + " title: " + title);
            if (login != null && password != null) {
                try {
                    Users user = new Users(login, password);
                    System.out.println(user.toString());
                    usersFacade.edit(user);
                    request.setAttribute("message", "User Update");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (text != null && title != null && id != null) {
                List< Articles> article = articlesFacade.findAll();
                Articles article2 = new Articles(Integer.parseInt(id), title, text, java.util.Calendar.getInstance().getTime());
                articlesFacade.edit(article2);
                request.setAttribute("message", "Article Update");
            }
            page = "/WEB-INF/views" + userPath + ".jsp";
        } else if ("/index".equals(userPath)) {
            getServletContext().setAttribute("articles", articlesFacade.findAll());
            page = "/index.jsp";
        }
        request.getRequestDispatcher(page).forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
