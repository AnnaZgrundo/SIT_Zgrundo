/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package converter.ejb;

import java.math.BigDecimal;
import javax.ejb.Stateless;


/**
 *
 * @author Admin
 */
@Stateless
public class Converter implements ConverterLocal {
    
    @Override
    public String reverse_f(String user_string) {
        String user_string2;
//        String a = "Палиндром";
//        String b = "Не палиндром";
//        String c = "lol";
//        user_string2 = new StringBuffer(user_string).reverse().toString();
//        if (user_string.equals(user_string2))
//            return a;
//        else 
//            return b;
         String a = "Больше гласных";
         String b = "Больше согласных";
         String c = "Согласных и гласных одинаковое количество";
         int count_consonant = 0; 
         int count_vowel = 0; 
         char [] m = user_string.toCharArray();
         for (int i =0; i<m.length;i++) {
             
             if (m[i] == 'b' || m[i] =='c' || m[i] =='d' || m[i] == 'f' || m[i] =='g' || m[i] == 'h' ||
                     m[i] == 'j' || m[i] =='k' || m[i] =='l' || m[i] == 'm' || m[i] =='n' || m[i] == 'p' ||
                     m[i] == 'q' || m[i] =='r' || m[i] =='s' || m[i] == 't' || m[i] =='v' || m[i] == 'w' ||
                     m[i] == 'x' || m[i] =='z')
                 count_consonant++;
             if (m[i] == 'a' || m[i] =='e' || m[i] =='i' || m[i] == 'o' || m[i] =='u' || m[i] == 'y')
                 count_vowel++;

                 }
         if (count_vowel>count_consonant)
             return a;
         if (count_vowel < count_consonant)
             return b;
         else
             return c;
    }
}