-- MySQL dump 10.13  Distrib 5.6.23, for Win32 (x86)
--
-- Host: localhost    Database: magazine
-- ------------------------------------------------------
-- Server version	5.5.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `articles`
--
CREATE SCHEMA IF NOT EXISTS `magazine` DEFAULT CHARACTER SET utf8 ;
DROP TABLE IF EXISTS `magazine`.`articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `magazine`.`articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL COMMENT 'Заголовок статьи',
  `text` text NOT NULL COMMENT 'Текст статьи',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата добавления статьи.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title_UNIQUE` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `magazine`.`articles` WRITE;
/*!40000 ALTER TABLE `magazine`.`articles` DISABLE KEYS */;
INSERT INTO `magazine`.`articles` VALUES (1,'Ан-225 «Мрия»','Ан-225 «Мрия» (укр. мрія — «мечта», внутреннее обозначение: изделие 402, по кодификации НАТО: Cossack — рус. казак) — транспортный самолёт сверхбольшой грузоподъёмности разработки ОКБ им. О. К. Антонова. Самый большой в мире самолет. Уникальный транспортный самолёт был спроектирован и построен на Киевском Механическом Заводе в 1984—1988 годах. Первый полёт был совершён 21 декабря 1988 года. Изначально было заложено 2 машины, в настоящее время один экземпляр находится в лётном состоянии и эксплуатируется украинской компанией Antonov Airlines. Второй экземпляр готов на 70 %.\nЛётно-технические характеристики\nЭкипаж, чел 7\nРазмах крыла, м 88.4\nДлина, м 84\nВысота, м 18.2\nПлощадь крыла, м2 905\nМасса пустого самолёта, кг 250 000\nМасса максимальная взлётная, кг 640 000\nТяга нефорсажная, кгс 1377\nМасса топлива нормальная, кг 300 000\nКрейсерская скорость , км/ч 850\nПрактическая дальность, км 15 400\nПрактическая дальность с максимальной нагрузкой, км 4500\nПрактический потолок, м 11 000\nПолезная нагрузка дo 250 000 кг груза\nДвигатели\nВариант Тип Модель Кол-во Мощность, л.с.\n1 ТВД Прогресс (Лотарев) Д-18Т 6\nВ остальном Ан-225 практически полностью соответствует самолёту Ан-124, что существенно облегчило и удешевило как его создание, так и эксплуатацию.\n•	При том, что самолёт создавался для перевозки компонентов ракет-носителей «Энергия» и космического корабля «Буран», к моменту окончания строительства первого Ан-225 все необходимые перевозки были сделаны самолётом ВМ-Т «Атлант», и в программе «Буран» Ан-225 поучаствовал только, перевезя «Буран» на Парижский авиасалон в мае 1989 года и совершив несколько показательных полётов на Байконуре в апреле 1991 года.\n•	Одну из главных ролей в эпизодах про разрушение Лас-Вегаса в фильме «2012» сыграл Ан-225 «Мрия». Для фильма создали фотореалистичную копию этого самолёта — первую в мире компьютерную модель Ан-225 «Мрия» с высочайшим уровнем детализации. В фильме присутствуют несколько искажений фактов о самолёте, а именно: значительно уменьшенный по длине грузовой отсек и несуществующий хвостовой грузовой люк (на самом деле откидывается вверх вся передняя часть самолета, за исключением кабины). Также на борт самолёта нанесена надпись «ANTONOV 500» и флаг Азербайджана.\n•	Самолёт также появляется в компьютерной игре Battlefield: Bad Company 2 в одном из заданий, где используется российскими войсками для доставки и активации скалярного оружия над территорией Соединённых Штатов. Однако в игре самолёт имеет лишь 4 двигателя, что позволяет говорить об ошибке разработчиков шутера или же об ошибке персонажа данной игры, неверно назвавшего стоящий на ВПП самолёт. В оригинальной английской версии, к тому же, название самолета произносится как «Мира». На самом деле самолетом из игры является Ан-124 «Руслан».\n•	В игре MiG-29 Fulcrum фирмы NovaLogic АН-225 стоит на второй ВПП.\n','2015-05-03 10:32:57'),(2,'Mars Science Laboratory','Mars Science Laboratory (сокр. MSL), «Марс сайенс лэборатори» («Марсианская научная лаборатория», МНЛ) — миссия НАСА, в ходе выполнения которой на Марс был успешно доставлен и эксплуатируется марсоход третьего поколения «Кьюрио́сити» (англ. Curiosity, МФА: [ˌkjʊərɪˈɒsɪti] — любопытство, любознательность[11]). Марсоход представляет собой автономную химическую лабораторию в несколько раз больше и тяжелее предыдущих марсоходов «Спирит» и «Оппортьюнити».[1][3] Аппарат должен будет за несколько месяцев пройти от 5 до 20 километров и провести полноценный анализ марсианских почв и компонентов атмосферы. Для выполнения контролируемой и более точной посадки использовались вспомогательные ракетные двигатели.[12]\n\nЗапуск «Кьюриосити» к Марсу состоялся 26 ноября 2011 год, мягкая посадка на поверхность Марса — 6 августа 2012. Предполагаемый срок службы на Марсе — один марсианский год (686 земных суток).\n\nMSL — часть долговременной программы НАСА по исследованию Марса роботизированными зондами Mars Exploration Program. В проекте помимо НАСА участвуют также Калифорнийский технологический институт и Лаборатория реактивного движения. Руководитель проекта — Дуг Маккистион (Doug McCuistion), сотрудник НАСА из отдела изучения других планет.[14] Полная стоимость проекта MSL составляет примерно 2,5 миллиарда долларов.[15]\n\nСпециалисты американского космического агентства НАСА решили отправить марсоход в кратер Гейла. В огромной воронке хорошо просматриваются глубинные слои марсианского грунта, раскрывающие геологическую историю красной планеты.','2015-05-03 10:32:57'),(3,'Moustiers Sainte-Marie. La ville de rêves','<h2>\n<p>Les traces de présence humaine dans les environs de Moustiers remontent à l’époque de Cro Magnon, il y a 30.000 ans.</p>\n</h2>\n<p></p>\n<p>A l’Age du Bronze, le peuplement s’intensifie : les tribus ligures occupent les plateaux environnants et s’implantent en construisant des places fortifiées (oppidas).</p>\n<p>Mais c’est au Ve siècle que débute véritablement l’occupation de l’actuel village : les moines de Lérins s’installent dans les grottes de tuf et fondent un monastère durant le VIème siècle. Cette présence ecclésiastique est à l’origine du nom de Moustiers Sainte-Marie (Monasterio au Moyen-Age).</p>\n<h3 class=\"spip\">Un développement au gré des soubresauts de l’Histoire</h3>\n<p>Les invasions maures des Xème et XIème siècles renvoient les habitants des alentours dans les grottes, pour se protéger. Mais c’est au cours des XIIè et XIIIè que s’édifient des fortifications et des maisons pendant que des moulins s’installent sur le torrent de l’Adou.</p>\n<p>Au cours du XIVème siècle, s’ajoutant à la peste de 1348, le village connaît une véritable hémorragie démographique liée aux querelles de succession du Comté de Provence.</p>\n<p>C’est avec le développement, au XVIè siècle, des industries mues par l’énergie hydraulique (tanneries, papeteries, etc.) que le village retrouve son essor. Mais à l’aube du XVIIème siècle, d’importantes intempéries mettent à mal les infrastructures et le village est de nouveau privé d’une grande partie de sa population.</p>\n<p></p>','2015-05-03 10:32:57');
/*!40000 ALTER TABLE `magazine`.`articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupuser`
--

DROP TABLE IF EXISTS `magazine`.`groupuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `magazine`.`groupuser` (
  `name` varchar(20) NOT NULL COMMENT 'Наименование группы',
  `users_login` varchar(15) NOT NULL COMMENT 'Вторичный ключ от таблицы users',
  PRIMARY KEY (`name`),
  KEY `fk_groupuser_users` (`users_login`),
  CONSTRAINT `fk_groupuser_users` FOREIGN KEY (`users_login`) REFERENCES `users` (`login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupuser`
--

LOCK TABLES `magazine`.`groupuser` WRITE;
/*!40000 ALTER TABLE `magazine`.`groupuser` DISABLE KEYS */;
INSERT INTO `magazine`.`groupuser` VALUES ('default','guest');
/*!40000 ALTER TABLE `magazine`.`groupuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupuser_has_articles`
--

DROP TABLE IF EXISTS `magazine`.`groupuser_has_articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `magazine`.`groupuser_has_articles` (
  `groupuser_name` varchar(20) NOT NULL,
  `articles_id` int(11) NOT NULL,
  PRIMARY KEY (`groupuser_name`,`articles_id`),
  KEY `fk_groupuser_has_articles_articles1` (`articles_id`),
  KEY `fk_groupuser_has_articles_groupuser1` (`groupuser_name`),
  CONSTRAINT `fk_groupuser_has_articles_articles1` FOREIGN KEY (`articles_id`) REFERENCES `articles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_groupuser_has_articles_groupuser1` FOREIGN KEY (`groupuser_name`) REFERENCES `groupuser` (`name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupuser_has_articles`
--

LOCK TABLES `magazine`.`groupuser_has_articles` WRITE;
/*!40000 ALTER TABLE `magazine`.`groupuser_has_articles` DISABLE KEYS */;
INSERT INTO `magazine`.`groupuser_has_articles` VALUES ('default',1),('default',2),('default',3);
/*!40000 ALTER TABLE `magazine`.`groupuser_has_articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `magazine`.`messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `magazine`.`messages` (
  `id` int(11) NOT NULL,
  `text` varchar(255) NOT NULL COMMENT 'Текст сообщения',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата мессаги',
  `users_login` varchar(15) NOT NULL COMMENT 'Юзер пославший мессагу',
  `articles_id` int(11) NOT NULL COMMENT 'Статье к которой послан комент',
  PRIMARY KEY (`id`),
  KEY `fk_messages_users1` (`users_login`),
  KEY `fk_messages_articles1` (`articles_id`),
  CONSTRAINT `fk_messages_articles1` FOREIGN KEY (`articles_id`) REFERENCES `articles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_messages_users1` FOREIGN KEY (`users_login`) REFERENCES `users` (`login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `magazine`.`messages` WRITE;
/*!40000 ALTER TABLE `magazine`.`messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `magazine`.`messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `magazine`.`users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `magazine`.`users` (
  `login` varchar(15) NOT NULL COMMENT 'Логин',
  `pass` varchar(45) NOT NULL COMMENT 'Пароль',
  PRIMARY KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `magazine`.`users` WRITE;
/*!40000 ALTER TABLE `magazine`.`users` DISABLE KEYS */;
INSERT INTO `magazine`.`users` VALUES ('guest','guest');
/*!40000 ALTER TABLE `magazine`.`users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-05-19 13:42:44
